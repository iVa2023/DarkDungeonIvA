package future.code.dark.dungeon.domen;

import future.code.dark.dungeon.GameFrame;
import future.code.dark.dungeon.config.Configuration;
import future.code.dark.dungeon.service.GameMaster;

import java.awt.event.ActionEvent;

public abstract class DynamicObject extends GameObject {

   public int CollectedCoins = 0;
   public static boolean GameWin = false;

    public DynamicObject(int xPosition, int yPosition, String imagePath) {
        super(xPosition, yPosition, imagePath);
    }
    public enum Direction {
        UP, DOWN, LEFT, RIGHT
    }

    public void move(Direction direction, int distance) {
        int tmpXPosition = getXPosition();
        int tmpYPosition = getYPosition();

        switch (direction) {
            case UP -> tmpYPosition -= distance;
            case DOWN -> tmpYPosition += distance;
            case LEFT -> tmpXPosition -= distance;
            case RIGHT -> tmpXPosition += distance;
        }

        if (isAllowedSurface(tmpXPosition, tmpYPosition) && isNextMoveCoin(tmpXPosition, tmpYPosition)) {
            xPosition = tmpXPosition;
            yPosition = tmpYPosition;
            CollectedCoins++;
        }

        if (isAllowedSurface(tmpXPosition, tmpYPosition) && isGameWon(tmpXPosition, tmpYPosition)){
            xPosition = tmpXPosition;
            yPosition = tmpYPosition;
            GameWin = true;
        }

        if (isAllowedSurface(tmpXPosition, tmpYPosition) && isNextNotMoveExit(tmpXPosition, tmpYPosition)) {
            xPosition = tmpXPosition;
            yPosition = tmpYPosition;
        }
    }

    protected Boolean isAllowedSurface(int x, int y) {
        return GameMaster.getInstance().getMap().getMap()[y][x] != Configuration.WALL_CHARACTER;
    }
    protected Boolean isNextNotMoveExit(int x, int y){
        return GameMaster.getInstance().getMap().getMap()[y][x] != Configuration.EXIT_CHARACTER;
    }
    protected Boolean isNextMoveCoin(int x, int y){
        for (int c = 0; c < GameMaster.getInstance().getCoinObjects().size(); c++){
            if (GameMaster.getInstance().getCoinObjects().get(c).getXPosition() == x
                    && GameMaster.getInstance().getCoinObjects().get(c).getYPosition() == y){
                GameMaster.getInstance().getCoinObjects().get(c).setCoinCollected(true);
              return true;
            }
        } return false;
    }

    protected Boolean isGameWon(int x, int y){
        return GameMaster.getInstance().getMap().getMap()[y][x] == Configuration.EXIT_CHARACTER && CollectedCoins == 9;
    }
}

