package future.code.dark.dungeon.domen;

import future.code.dark.dungeon.config.Configuration;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;

public class Coin extends GameObject {
    public static Coin getCoin() {
        return coin;
    }

    public boolean getCoinCollected() {
        return coinCollected;
    }

    public void setCoinCollected(boolean coinCollected) {
        this.coinCollected = coinCollected;
    }

    public boolean coinCollected;
    private static Coin coin;

    public Coin(int xPosition, int yPosition) {
        super(xPosition, yPosition, Configuration.COIN_SPRITE);
    }
}

