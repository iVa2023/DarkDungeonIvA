package future.code.dark.dungeon;

import future.code.dark.dungeon.controller.MovementController;
import future.code.dark.dungeon.service.GameMaster;

import static future.code.dark.dungeon.config.Configuration.*;
import static future.code.dark.dungeon.domen.DynamicObject.GameWin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

public class GameFrame extends JPanel implements ActionListener {

    private final GameMaster gameMaster;
    public static GameFrame example;

    public static synchronized GameFrame getExample() {
        return example;
    }

    private static final ImageIcon winImage = new ImageIcon(GAME_WON);

    public GameFrame(JFrame frame) {
        Timer timer = new Timer(GAME_FRAMES_PER_SECOND, this);
        this.gameMaster = GameMaster.getInstance();

        frame.setSize(gameMaster.getMap().getWidth() * SPRITE_SIZE, gameMaster.getMap().getHeight() * SPRITE_SIZE);
        frame.setLocationRelativeTo(null);
        timer.start();
        frame.addKeyListener(new MovementController(gameMaster.getPlayer()));
    }

    @Override
    public void paint(Graphics graphics) {
        gameMaster.renderFrame(graphics);
    }

    @Override
    public void actionPerformed(ActionEvent e) { // Always triggered by Timer
        repaint();
    }
}